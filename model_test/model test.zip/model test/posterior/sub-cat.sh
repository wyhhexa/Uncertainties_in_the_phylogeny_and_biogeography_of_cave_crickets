#!/bin/bash
#SBATCH --job-name=catgtr
#SBATCH --time=66:00:00
#SBATCH -p amd_512
#SBATCH -N 1
#SBATCH -n 64
source /public1/soft/modules/module.sh
module purge
module load mpi/intel/17.0.7-thc gcc/7.3.0-wzm
export PATH=/public1/home/scg1867/new-pbmpi1.9/pbmpi-master/data:$PATH
mpirun  pb_mpi  -d data.phy -T tree.tre  -gtr  -cat  -dgam 4 -x 3 200 catdata
